Child Security - Linux O'rnatish Qo'llanmasi
=============================================
1. Ushbu papkada terminalni oching.
2. Quyidagi buyruqni bering:
   chmod +x ChildSecurity_Linux_Setup.sh
   ./ChildSecurity_Linux_Setup.sh
3. Ish stolingizda "Child Security" paydo bo'ladi!
